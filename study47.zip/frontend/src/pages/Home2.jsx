import React, { useState } from 'react';

const Home2 = () => {
  const [inputValue, setInputValue] = useState("");
  const [isFocused, setIsFocused] = useState(false);

  // --- 스타일 정의 ---
  const containerStyle = {
    display: 'flex',
    flexDirection: 'column',
    justifyContent: 'center', // 세로 중앙
    alignItems: 'center',     // 가로 중앙
    minHeight: '100vh',
    backgroundColor: '#f8fafd',
    padding: '20px',
    fontFamily: '-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif'
  };

  const searchBoxStyle = {
    width: '100%',
    maxWidth: '700px',
    backgroundColor: '#ffffff',
    borderRadius: '28px',
    border: isFocused ? '1px solid #dfe1e5' : '1px solid #f0f4f9',
    boxShadow: isFocused 
      ? '0 4px 12px rgba(60,64,67,0.15)' 
      : '0 1px 6px rgba(32,33,36,0.05)',
    transition: 'all 0.3s ease',
    display: 'flex',
    flexDirection: 'column',
    padding: '12px'
  };

  const textareaStyle = {
    width: '100%',
    padding: '10px 16px',
    fontSize: '18px',
    color: '#3c4043',
    border: 'none',
    outline: 'none',
    backgroundColor: 'transparent',
    resize: 'none',
    minHeight: '44px',
    lineHeight: '1.5'
  };

  const toolbarStyle = {
    display: 'flex',
    alignItems: 'center',
    padding: '0 8px'
  };

  const plusButtonStyle = {
    width: '40px',
    height: '40px',
    borderRadius: '50%',
    border: 'none',
    backgroundColor: 'transparent',
    cursor: 'pointer',
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
    fontSize: '24px',
    color: '#5f6368',
    transition: 'background-color 0.2s',
    fontWeight: '300'
  };

  const footerStyle = {
    marginTop: '24px',
    fontSize: '12px',
    color: '#70757a',
    textAlign: 'center'
  };

  return (
    <div style={containerStyle}>
      {/* 입력창 본체 */}
      <div style={searchBoxStyle}>
        <textarea
          rows="1"
          placeholder="무엇이든 물어보세요"
          style={textareaStyle}
          value={inputValue}
          onChange={(e) => setInputValue(e.target.value)}
          onFocus={() => setIsFocused(true)}
          onBlur={() => setIsFocused(false)}
        />

        <div style={toolbarStyle}>
          {/* 왼쪽: 플러스 버튼만 유지 */}
         
            
         
        </div>
      </div>

      <div style={footerStyle}>
        
      </div>
    </div>
  );
};

export default Home2;
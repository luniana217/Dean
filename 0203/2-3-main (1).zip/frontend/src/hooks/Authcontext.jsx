import { createContext, useContext, useEffect, useState } from "react";
import { useNavigate } from "react-router";
import axios from "axios"

const api = axios.create({
  baseURL: "http://localhost:8000",
  withCredentials: true,
  headers: {
    "Content-Type": "application/json",
  },
}) //쿠키 및 api연동관련

// Context 생성
export const AuthContext = createContext();

// Custom Hook
export function useAuth() {
  return useContext(AuthContext);
}

// Provider 컴포넌트
export function AuthProvider({ children }) {
  const [isLogin, setIsLogin] = useState(false);
  const nav = useNavigate()

  const setAuth = userData => {
    localStorage.setItem("user", userData)
    setIsLogin(true)
    nav("/")
  }

  const removeAuth = () => {
    localStorage.removeItem("user");
    setIsLogin(false);
    api.post("/logout").finally(() => {
    nav("/");
    })
    .catch(err => console.error(err))
  }

  const checkAuth = () => {
    return localStorage.getItem("user") ? true : false    
  }

  useEffect(()=>{
    if(localStorage.getItem("user")) setIsLogin(true)

  },[])

  return (
    <AuthContext.Provider value={{ isLogin, setAuth, removeAuth, checkAuth }}>
      {children}
    </AuthContext.Provider>
  );
}

export default AuthProvider